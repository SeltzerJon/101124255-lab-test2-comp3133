import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-missionlist',
  templateUrl: './missionlist.component.html',
  styleUrls: ['./missionlist.component.css']
})
export class MissionlistComponent implements OnInit {
  missions: any[] = [];
  filteredMissions: any[] = [];
  selectedMission: any;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.fetchMissions();
  }

  fetchMissions() {
    this.http.get<any[]>('https://api.spacexdata.com/v3/launches').subscribe(
      (data) => {
        this.missions = data;
        this.filteredMissions = [...this.missions];
      },
      (error) => {
        console.error('Error fetching SpaceX launches:', error);
      }
    );
  }

  applyFilterByYear(year: string) {
    if (year) {
      this.filteredMissions = this.missions.filter(mission => mission.launch_year === year);
    } else {
      this.filteredMissions = [...this.missions];
    }
  }
  showMissionDetails(mission: any) {
    this.selectedMission = mission;
  }
}
